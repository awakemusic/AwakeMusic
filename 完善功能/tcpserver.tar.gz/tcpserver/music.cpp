#include "music.h"

Music::Music(QString name, QString singer, QString lyric, QString album, QString audiopath):m_name{name}, m_singer{singer}, m_lyric{lyric}, m_album{album}, m_audiopath{audiopath}
{}
